
export interface Image {
    url: string;
    id: string;
}

export interface RootObject {
    images: Image[];
}
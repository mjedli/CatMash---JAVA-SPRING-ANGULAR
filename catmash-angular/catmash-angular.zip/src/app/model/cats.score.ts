export interface RootObject {
    id: string;
    url: string;
    score: number;
}